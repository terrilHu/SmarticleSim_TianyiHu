"""
config.py  ─  All global parameters for the Smarticle simulation.
Edit this file to change experiment settings.
"""

import math
import random

# =============================================================================
# Global Configuration  ← all tunable parameters are defined here
# =============================================================================

# ── Trial / seed ──────────────────────────────────────────────────────────────
TRIAL_SEED_BASE   = 12345
N_TRIALS_GLOBAL   = 1       # 0 means auto-read from initial-conditions file
MAX_RUNTIME       = 60.0    # in seconds

# ── Initial-condition selection (only used when ALREADY_SPWANED = True) ────
# "sequential" : use init_conditions[0], [1], [2] ... in order (default)
# "random"     : draw without replacement each run; reshuffles when the pool
#                is exhausted (trials may repeat across reshuffles but never
#                within one)
INIT_SELECTION    = "random"

# ── Video recording ───────────────────────────────────────────────────────────
RECORD_VIDEO      = True
RECORD_POLICY     = "mod"   # "mod" | "first_n" | "both"
RECORD_EVERY_K    = 1       # record trials where (trial_id % K == 0)
RECORD_FIRST_N    = 200       # record the first N trials
VIDEO_FPS         = 30      # output video fps
VIDEO_STRIDE      = 2       # write 1 frame every N simulation frames
VIDEO_CODEC       = "mp4v"  # OpenCV fourcc

# ── Warmup ────────────────────────────────────────────────────────────────────
# WARMUP_STEPS: number of physics steps for the joint-angle warm-up ramp.
# With dt = 1/180 s, WARMUP_STEPS=180 => 1 s warm-up.  0 = instant jump.
WARMUP_STEPS        = 180
# When True, ALL data recording (CSV, npz) and video recording begin only after
# every smarticle's warm-up counter has finished.
RECORD_AFTER_WARMUP = True

# ── Screen / geometry ─────────────────────────────────────────────────────────
W, H              = 900, 760   # screen size (pixels)
SCREEN_MARGIN     = 26         # margin between outer wall and window edge

# ── Reference geometry (used for auto-scaling) ────────────────────────────────
BASE_N_REF        = 17
BASE_WALL_THICK   = 20
BASE_MAIN_LEN, BASE_MAIN_W = 70, 41
BASE_ARM_LEN,  BASE_ARM_W  = 70, 6

# ── Experiment size ───────────────────────────────────────────────────────────
N_SMARTICLES      = 17         # number of smarticles in the simulation
INNER_R_UNSCALED  = 245        # inner ring radius before scaling

# ── Auto-scaling (do not edit unless you know what you are doing) ─────────────
_outer_need       = INNER_R_UNSCALED + BASE_WALL_THICK
_outer_allow      = (min(W, H) / 2.0) - SCREEN_MARGIN
SCALE             = min(1.0, _outer_allow / max(1.0, _outer_need))
INNER_R           = max(20, int(INNER_R_UNSCALED * SCALE))
WALL_THICK        = max(8,  int(BASE_WALL_THICK   * SCALE))
WALL_SEGMENTS     = int(max(120, min(480, 240 * math.sqrt(max(1, N_SMARTICLES) / BASE_N_REF))))
MAIN_LEN, MAIN_W  = max(18, int(BASE_MAIN_LEN * SCALE)), max(10, int(BASE_MAIN_W * SCALE))
ARM_LEN,  ARM_W   = max(18, int(BASE_ARM_LEN  * SCALE)), max(3,  int(BASE_ARM_W  * SCALE))

# ── Wall physics ──────────────────────────────────────────────────────────────
WALL_FRICTION     = 0.9
WALL_ELASTICITY   = 0.0

# ── Heterogeneous bodies (per-individual physical characteristics) ────────────
# When ENABLE_HETEROGENEOUS_BODIES is False the simulation is fully homogeneous
# and behaves EXACTLY as before (every robot uses the global geometry above).
#
# When True, every robot is assigned a "body type" by index via BODY_ASSIGNMENT.
# A body type is a dict of OVERRIDES on the base (UNSCALED) geometry; anything not
# listed falls back to the BASE_* defaults, and the same SCALE pipeline + clamps
# used for the global geometry are applied automatically (see bodies.py).
#
# Recognised override keys:
#   "main_len_base", "main_w_base", "arm_len_base", "arm_w_base"  (unscaled px)
#   "mass_main", "mass_arm"   (absolute, already-scaled; optional)
# If a mass is omitted it is auto-derived from the area ratio relative to the
# homogeneous default, so a bigger arm is automatically heavier.
ENABLE_HETEROGENEOUS_BODIES = False

# Library of reusable body types ("species"). "default" = the global geometry.
BODY_TYPES = {
    "default":   {},                       # global BASE_* geometry, unchanged
    "long_arm":  {"arm_len_base": 110},    # longer arms (base 70 -> 110)
    "short_arm": {"arm_len_base": 45},     # shorter arms (base 70 -> 40)
    # "heavy":   {"main_w_base": 60, "mass_main": 400.0},
}

# Per-robot assignment; length MUST equal N_SMARTICLES. Each entry is a key of
# BODY_TYPES. Example for a 17-robot mixed population:
#   BODY_ASSIGNMENT = (["long_arm"] * 6) + (["short_arm"] * 6) + (["default"] * 5)
BODY_ASSIGNMENT = ["default"] * 17
random.shuffle(BODY_ASSIGNMENT)

# Per-robot command array; length must equal N_SMARTICLES.
# Each entry is a signed 3-digit integer ±XYZ where:
#   X (hundreds, 0-8) : initial phase  — 0 = random, 1-8 from table
#   Y (tens,     1-6) : amplitude      — lookup table index
#   Z (units,    1-9) : frequency      — lookup table index
#   sign (+)          : both joints same phase
#   sign (-)          : joints in antiphase (phase2 = phase1 + pi)
# Example: -226 → antiphase, |phase|=pi/2, A=pi/6, f=3Hz
#          +051 → same phase, phase=random, A=pi*5/12, f=0.5Hz
#COMMAND_ARRAY = [862] * N_SMARTICLES   # default: same phase pi*5/4, A=pi/2, f=3Hz
COMMAND_ARRAY = [862] * 9 + [462] * 8
random.shuffle(COMMAND_ARRAY)

# GAIT_BY_TYPE will be automatically chosen when heterogeneous is enabled
GAIT_BY_TYPE = {
    "default":    -851,    
    "long_arm":  -426,   
    "short_arm":  861,   
}

# ── Ring (confining boundary) options ─────────────────────────────────────────
# The boundary can be FIXED (anchored to the world) or MOVABLE (free to move),
# and a smooth CIRCLE or a regular N-gon whose corners are free-rotating hinges.
#
#   RING_MOVABLE = False, RING_SHAPE = "circle"  →  the original fixed circular
#   ring, reproduced exactly.  Any other combination is a new variant.
#
# Combinations:
#   circle  + fixed    : original smooth static wall.
#   circle  + movable  : one rigid ring body, free to translate & rotate.
#   polygon + fixed    : regular n-gon wall held in place at its corners.
#   polygon + movable  : n rigid edge-links joined by free-rotating corner
#                        hinge joints — a deformable loop the swarm can reshape.
RING_MOVABLE   = True        # False = fixed (default); True = movable
RING_SHAPE     = "polygon"     # "circle" (default) | "polygon"
RING_N_SIDES   = 35            # number of sides when RING_SHAPE == "polygon" (>= 3)
# Total mass of a MOVABLE ring, distributed over its segments / edge-links.
# Ignored when RING_MOVABLE is False.  Heavier = harder for the swarm to shove.
RING_MASS      = 1000.0 * (SCALE ** 2)
# Number of color bands painted around the ring, for observing rotation/translation.
# None or 0  →  no special coloring (pymunk default gray/blue).
# Positive N  →  divide the ring into N equal angular bands, each a distinct
#                high-contrast color, cycling through a fixed palette.
# Good values: 2 (half-and-half), 4 (quadrants), 6, 8.
# Works with all shape / movable combinations.
RING_COLOR_BANDS = 4

# ── Actuation ─────────────────────────────────────────────────────────────────
# === THIS IS WHERE YOU CONTROL JOINT MOTION ===
# Desired joint angle trajectory: theta(t) = A * sin(omega * t + phase)
# Left arm  uses A1, omega1, phase1 (set per-robot in run_trial via COMMAND_ARRAY)
# Right arm uses A2, omega2, phase2
A_DEG_NOM         = 30.0    # nominal amplitude (deg) [kept for back-compat]
A_DEG_NOM1        = 90.0    # left  arm amplitude (deg)
A_DEG_NOM2        = 90.0    # right arm amplitude (deg)
OMEGA_NOM         = 10.0    # nominal frequency (rad/s) [kept for back-compat]
OMEGA_NOM1        = 3 * 2 * math.pi   # left  arm frequency (rad/s)
OMEGA_NOM2        = 3 * 2 * math.pi   # right arm frequency (rad/s)
# RATE_LIM          = 8.0     # motor velocity clamp (rad/s)
# ANG_DAMP          = 0.965   # per-step angular velocity damping factor
# SPACE_DAMP        = 0.985   # velocity reserved each step
# JOINT_LIMIT_DEG   = 85.0    # hard joint angle limit (deg)
# KP_NOM            = 30.0    # proportional gain for motor PD controller

RATE_LIM          = 8.0     # motor velocity clamp (rad/s)
ANG_DAMP          = 0.8     # per-step angular velocity damping factor
LIN_DAMP          = 0.8     # per-step linear velocity damping factor
SPACE_DAMP        = 1.0     # velocity reserved each step
JOINT_LIMIT_DEG   = 95.0    # hard joint angle limit (deg)
KP_NOM            = 60.0    # proportional gain for motor PD controller


# ── Coupling / interaction model ──────────────────────────────────────────────
L    = MAIN_W
S    = MAIN_LEN
WC   = 1.0
L_s  = (MAIN_LEN + 2 * ARM_LEN) / 2
R0   = L_s + 0.01 * S
a0   = 0.1
a1   = 1.0
g0   = 0.01

# ── Motor torque & mass (scaled) ──────────────────────────────────────────────
BASE_MAX_MOTOR_TORQUE = 3e7
MAX_MOTOR_TORQUE_NOM  = BASE_MAX_MOTOR_TORQUE * (SCALE ** 4)
# BASE_MAX_MOTOR_TORQUE = 3e7
# MAX_MOTOR_TORQUE_NOM  = BASE_MAX_MOTOR_TORQUE * (SCALE ** 4)
BASE_MASS_MAIN        = 172.14
BASE_MASS_ARM         = 6.40
MASS_MAIN             = BASE_MASS_MAIN * (SCALE ** 2)
MASS_ARM              = BASE_MASS_ARM  * (SCALE ** 2)

# ── Physics stability ─────────────────────────────────────────────────────────
SPACE_DAMPING     = 0.985
SPACE_ITERATIONS  = 60
COLLISION_SLOP    = 0.06 * SCALE
V_MAX             = 900.0 * SCALE
W_MAX             = 35.0

# ── Spawn / packing ───────────────────────────────────────────────────────────
PEN_EPS           = 0.1 * SCALE
SETTLE_STEPS      = 10
SETTLE_DT         = 1 / 800.0

# ── Parameter jitter (diversity across robots) ────────────────────────────────
ENABLE_PARAMETER_JITTER = False
A_JITTER_FRAC     = 0.20   # +/-20% amplitude variation
OMEGA_JITTER_FRAC = 0.20   # +/-20% frequency variation
KP_JITTER_FRAC    = 0.30   # +/-30% kp variation
TORQUE_JITTER_FRAC= 0.30   # +/-30% motor torque variation

# ── Initial angle mixture (used by sample_initial_joint_angle) ────────────────
INIT_MIX_FOLDED   = 0.25
INIT_MIX_STRAIGHT = 0.35
INIT_MIX_UNIFORM  = 0.40
STRAIGHT_BAND_DEG = 12.0

# ── Stepping / rendering ──────────────────────────────────────────────────────
SIM_DT              = 1.0 / 180.0
RENDER_FPS_PREVIEW  = 60
RENDER_FPS_HEADLESS = 60

# ── Misc ──────────────────────────────────────────────────────────────────────
SCORE_VALID         = False
SAVE_NPY            = False
ALREADY_SPWANED     = True
rho                 = N_SMARTICLES / (W * H)  # number density

# =============================================================================
# End of global configuration
# =============================================================================
